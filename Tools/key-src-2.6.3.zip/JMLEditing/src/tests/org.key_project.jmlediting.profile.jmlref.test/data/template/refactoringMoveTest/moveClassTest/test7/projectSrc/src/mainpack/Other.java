package mainpack;

public class Other {
    public static int balance;
}