package test;

public class Dest {
   public static int fieldToMove;
}