package test1p2;

public class Params {
       
}