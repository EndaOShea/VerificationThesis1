package test;

public class Other {
    
    //@ invariant Other.balance > 0;
    public static int balance;
    
}