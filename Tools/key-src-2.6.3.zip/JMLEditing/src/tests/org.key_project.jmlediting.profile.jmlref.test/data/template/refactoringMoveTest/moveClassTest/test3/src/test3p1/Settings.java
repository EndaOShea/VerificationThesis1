package test3p1;

public class Settings {
    public static int x;
    
    public class RandomSettings{
        public int y;
    }
}
