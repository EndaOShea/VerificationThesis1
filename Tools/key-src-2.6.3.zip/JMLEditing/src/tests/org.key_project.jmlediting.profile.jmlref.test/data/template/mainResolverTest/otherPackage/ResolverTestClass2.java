package resolver.test.otherPackage;

public class ResolverTestClass2 {
    public static int staticField = 101;
    public static int staticMethod() { return 0; }
}