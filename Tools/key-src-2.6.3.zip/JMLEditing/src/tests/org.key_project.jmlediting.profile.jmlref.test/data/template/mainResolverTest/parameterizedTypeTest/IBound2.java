package resolver.test.parameterizedTypeTest;

public interface IBound2 {
   
   public boolean methodFromIBound2();
}