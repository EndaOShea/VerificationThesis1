package destPackage;

public class SourceClass {
   public static int fieldToMove;
   
   public static int someField;
}