package resolver.test;

class ResolverTestSuper {
   protected int superField;
   protected int superMethod(int param) { return 0; }
}