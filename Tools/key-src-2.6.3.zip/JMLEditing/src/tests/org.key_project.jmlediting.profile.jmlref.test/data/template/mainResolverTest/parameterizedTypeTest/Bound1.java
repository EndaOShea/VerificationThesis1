package resolver.test.parameterizedTypeTest;

public class Bound1 {
   
   public boolean methodFromBound1() {
      return true;
   }
}