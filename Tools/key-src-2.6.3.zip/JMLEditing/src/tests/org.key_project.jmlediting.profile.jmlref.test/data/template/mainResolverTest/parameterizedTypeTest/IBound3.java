package resolver.test.parameterizedTypeTest;

public interface IBound3 {
   
   public Main2<Boolean> methodFromIBound3();
}