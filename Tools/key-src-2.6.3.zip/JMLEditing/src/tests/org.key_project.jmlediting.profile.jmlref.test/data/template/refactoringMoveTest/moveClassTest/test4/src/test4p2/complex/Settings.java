package test4p2.complex;

public class Settings {
    public static int x;
    
    public class RandomSettings{
        public int y;
    }
}
