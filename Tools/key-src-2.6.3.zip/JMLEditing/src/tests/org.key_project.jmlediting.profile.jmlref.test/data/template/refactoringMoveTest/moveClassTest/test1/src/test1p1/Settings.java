package test1p1;

public class Settings {
    public static int x;
    
    public class RandomSettings{
        public int y;
    }
}
