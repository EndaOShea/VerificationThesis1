package test2p1;

public class Settings {
    public static int x;
    
    public class RandomSettings{
        public int y;
    }
    
    public static void go(){
        System.out.println("GO");
    }
}
