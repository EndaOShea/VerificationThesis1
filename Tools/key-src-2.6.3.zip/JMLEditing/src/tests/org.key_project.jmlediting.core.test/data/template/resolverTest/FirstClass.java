package test;

import test.subpackage.SecondClass;

public class FirstClass extends SuperClass {
   public String publicFirstClass;
   private int privateFirstClass;
   protected float protectedFirstClass;
   long packageFirstClass;
   public SecondClass secondClassRef;

   public class NestedInFirstClass {
      public String publicNestedInFirstClass;
      private int privateNestedInFirstClass;
      protected long protectedNestedInFirstClass;
      long packageNestedInFirstClass;
      
      public void f() {
         NestedInSu
      }
   }
}
