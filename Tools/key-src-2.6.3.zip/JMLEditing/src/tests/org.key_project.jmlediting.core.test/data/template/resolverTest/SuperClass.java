package test;

public class SuperClass {
   public String publicSuperClass;
   private int privateSuperClass;
   protected float protectedSuperClass;
   long packageSuperClass;

   public class NestedInSuperClass {
      public String publicNestedInSuperClass;
      private int privateNestedInSuperClass;
      protected long protectedNestedInSuperClass;
      long packageNestedInSuperClass;
   }
   
   public void main() {
     
      
   }
}
