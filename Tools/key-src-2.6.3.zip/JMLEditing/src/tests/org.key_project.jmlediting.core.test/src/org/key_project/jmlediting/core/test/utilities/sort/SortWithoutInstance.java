package org.key_project.jmlediting.core.test.utilities.sort;

import org.key_project.jmlediting.core.profile.syntax.AbstractKeywordSort;

public class SortWithoutInstance extends AbstractKeywordSort {
   public SortWithoutInstance() {
      super("WithoutInstance");
   }
}