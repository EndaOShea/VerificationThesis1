/**
 * This package Contains the extension for the Java Outline.
 */
package org.key_project.jmlediting.ui.outline;

