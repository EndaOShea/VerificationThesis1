/**
 * This package provides helpers for the JMLEditing UI.
 */
package org.key_project.jmlediting.ui.util;

