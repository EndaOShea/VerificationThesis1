/**
 * This package provides classes to add entries to the eclipse preferences and the project properties window.
 */
package org.key_project.jmlediting.ui.preferencepages;

