/**
 * This package contains classes to handle auto formatting oj JML code.
 */
package org.key_project.jmlediting.ui.format;

