/**
 * This package contains the support for sequence expressions in KeY.
 */
package org.key_project.jmlediting.profile.key.seq;

