/**
 * This package contains support for bounded quantifiers of KeY.
 */
package org.key_project.jmlediting.profile.key.bounded_quantifier;

