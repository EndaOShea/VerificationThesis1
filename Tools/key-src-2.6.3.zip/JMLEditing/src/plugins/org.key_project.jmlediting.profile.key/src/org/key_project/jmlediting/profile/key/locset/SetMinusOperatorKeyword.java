package org.key_project.jmlediting.profile.key.locset;


public class SetMinusOperatorKeyword extends LocSetBinaryOperatorKeyword {

   public SetMinusOperatorKeyword() {
      super("\\set_minus");
   }

   @Override
   public String getDescription() {
      return null;
   }

}
