/**
 * Contains a collection of different key keywords.
 */
package org.key_project.jmlediting.profile.key.other;

