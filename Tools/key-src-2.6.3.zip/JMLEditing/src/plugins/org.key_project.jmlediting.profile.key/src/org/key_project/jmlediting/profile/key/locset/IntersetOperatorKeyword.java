package org.key_project.jmlediting.profile.key.locset;

public class IntersetOperatorKeyword extends LocSetBinaryOperatorKeyword {

   public IntersetOperatorKeyword() {
      super("\\intersect");
   }

   @Override
   public String getDescription() {
      return null;
   }

}
