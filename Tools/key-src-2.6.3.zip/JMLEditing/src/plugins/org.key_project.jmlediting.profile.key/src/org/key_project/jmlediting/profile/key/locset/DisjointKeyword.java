package org.key_project.jmlediting.profile.key.locset;

public class DisjointKeyword extends LocSetBinaryOperatorKeyword {

   public DisjointKeyword() {
      super("\\disjoint");
   }

   @Override
   public String getDescription() {
      return null;
   }

}
