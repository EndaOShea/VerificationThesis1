package org.key_project.jmlediting.profile.key.locset;


public class SetUnionOperatorKeyword extends LocSetBinaryOperatorKeyword {

   public SetUnionOperatorKeyword() {
      super("\\set_union");
   }

   @Override
   public String getDescription() {
      return null;
   }

}
