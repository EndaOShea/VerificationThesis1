/**
 * Classes to support the location set keywords of KeY.
 */
package org.key_project.jmlediting.profile.key.locset;

