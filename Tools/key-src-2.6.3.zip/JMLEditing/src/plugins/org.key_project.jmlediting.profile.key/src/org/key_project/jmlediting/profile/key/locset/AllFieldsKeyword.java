package org.key_project.jmlediting.profile.key.locset;

public class AllFieldsKeyword extends LocSetUnaryOperatorKeyword {

   public AllFieldsKeyword() {
      super("\\all_fields");
   }

   @Override
   public String getDescription() {
      return null;
   }

}
