package org.key_project.jmlediting.profile.key.locset;

public class SubsetKeyword extends LocSetBinaryOperatorKeyword {

   public SubsetKeyword() {
      super("\\subset");
   }

   @Override
   public String getDescription() {
      return null;
   }

}
