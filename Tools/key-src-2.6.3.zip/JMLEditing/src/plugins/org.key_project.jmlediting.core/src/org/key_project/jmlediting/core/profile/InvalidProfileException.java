package org.key_project.jmlediting.core.profile;

public class InvalidProfileException extends Exception {

   /**
    *
    */
   private static final long serialVersionUID = 1465444193962729663L;

   public InvalidProfileException(final String message, final Throwable cause) {
      super(message, cause);
      // TODO Auto-generated constructor stub
   }

   public InvalidProfileException(final String message) {
      super(message);
      // TODO Auto-generated constructor stub
   }

   public InvalidProfileException(final Throwable cause) {
      super(cause);
      // TODO Auto-generated constructor stub
   }

}
