package org.key_project.jmlediting.core.dom;

public interface INodePrinter {

    public String print(IASTNode node);
}
