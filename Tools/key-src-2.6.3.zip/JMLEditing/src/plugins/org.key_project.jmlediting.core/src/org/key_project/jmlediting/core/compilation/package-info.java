/**
 * This package contains classes which takes part in the compilation process of the JDT.
 */
package org.key_project.jmlediting.core.compilation;

