package org.key_project.jmlediting.core.profile.syntax;

public class MalformedKeywortSortException extends RuntimeException {

   /**
    *
    */
   private static final long serialVersionUID = -6613635633825505534L;

   public MalformedKeywortSortException(final String message,
         final Throwable cause) {
      super(message, cause);
      // TODO Auto-generated constructor stub
   }

   public MalformedKeywortSortException(final String message) {
      super(message);
      // TODO Auto-generated constructor stub
   }

}
