/**
 * Provides classes for finding CommentRanges in a given String.
 * Provides helper Classes to Resolve Java in JML and Type Declarations
 */
package org.key_project.jmlediting.core.utilities;

