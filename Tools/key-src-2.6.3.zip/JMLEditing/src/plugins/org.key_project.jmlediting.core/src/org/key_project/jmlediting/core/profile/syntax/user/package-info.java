/**
 * Contains classes which allows the user to define keywords dynamically
 * without providing profile plugins.
 */
package org.key_project.jmlediting.core.profile.syntax.user;

