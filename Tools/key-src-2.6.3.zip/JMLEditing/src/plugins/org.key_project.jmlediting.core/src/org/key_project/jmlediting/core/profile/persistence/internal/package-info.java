/**
 * Implementation of profile persistence.
 */
package org.key_project.jmlediting.core.profile.persistence.internal;

