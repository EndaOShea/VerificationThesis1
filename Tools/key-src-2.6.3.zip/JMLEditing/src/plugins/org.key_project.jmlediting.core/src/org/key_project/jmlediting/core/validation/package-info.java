/**
 *
 */
/**
 * @author David Giessing
 * Provides Classes for Validating JML Specifications.
 */
package org.key_project.jmlediting.core.validation;