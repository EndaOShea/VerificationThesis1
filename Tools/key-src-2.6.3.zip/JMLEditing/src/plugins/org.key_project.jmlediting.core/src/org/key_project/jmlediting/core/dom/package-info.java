/**
 * Provides classes for the AST representation of JML annotations.
 */
package org.key_project.jmlediting.core.dom;

