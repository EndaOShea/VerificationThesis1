/**
 * Provides classes to define a JML profile.
 */
package org.key_project.jmlediting.core.profile;

