package org.key_project.jmlediting.core.parser;

public interface IRecursiveParseFunction extends ParseFunction {

   void defineAs(ParseFunction p);

}
