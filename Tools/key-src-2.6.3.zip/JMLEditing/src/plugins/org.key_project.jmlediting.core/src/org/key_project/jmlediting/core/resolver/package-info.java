/**
 * Contains classes for resolving variables and functions inside JML comments.
 * 
 * @author Christopher Beckmann
 *
 */
package org.key_project.jmlediting.core.resolver;