package org.key_project.jmlediting.core.resolver;

public enum ResolveResultType {
   UNSPECIFIED, PARAMETER, METHOD, FIELD, CLASS, ARRAY_ACCESS, ARRAY_LENGTH
}