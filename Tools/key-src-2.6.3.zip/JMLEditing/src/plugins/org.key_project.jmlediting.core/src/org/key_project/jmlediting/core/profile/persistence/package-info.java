/**
 * This package provides support for persisting user defined JML profiles.
 */
package org.key_project.jmlediting.core.profile.persistence;

