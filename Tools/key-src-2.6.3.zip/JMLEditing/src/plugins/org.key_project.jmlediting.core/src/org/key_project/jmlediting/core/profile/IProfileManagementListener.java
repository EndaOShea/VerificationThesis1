package org.key_project.jmlediting.core.profile;

public interface IProfileManagementListener {

   void newProfileAdded(IJMLProfile newProfile);

}
