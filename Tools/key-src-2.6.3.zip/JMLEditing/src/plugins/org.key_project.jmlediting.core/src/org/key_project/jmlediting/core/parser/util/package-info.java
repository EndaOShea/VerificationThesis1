/**
 * Contains utility classes for parsing for the jml reference profile.
 */
package org.key_project.jmlediting.core.parser.util;

