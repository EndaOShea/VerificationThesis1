/**
 * Package containing classes to define syntax for a JML profile.
 */
package org.key_project.jmlediting.core.profile.syntax;

