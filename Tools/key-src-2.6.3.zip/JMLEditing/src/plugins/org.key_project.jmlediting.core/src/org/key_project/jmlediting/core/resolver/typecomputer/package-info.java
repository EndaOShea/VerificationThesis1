/**
 * 
 * @author Christopher Beckmann
 *
 */
package org.key_project.jmlediting.core.resolver.typecomputer;