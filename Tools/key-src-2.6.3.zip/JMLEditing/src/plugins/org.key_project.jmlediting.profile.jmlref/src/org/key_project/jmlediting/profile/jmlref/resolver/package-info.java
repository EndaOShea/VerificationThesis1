/**
 * Default Resolver functionality for default JML.
 * 
 * @author Christopher Beckmann
 *
 */
package org.key_project.jmlediting.profile.jmlref.resolver;