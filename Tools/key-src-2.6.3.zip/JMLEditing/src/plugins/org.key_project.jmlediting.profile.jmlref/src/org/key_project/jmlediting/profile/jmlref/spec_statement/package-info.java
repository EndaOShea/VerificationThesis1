/**
 * This package contains classes to support specification statements.
 */
package org.key_project.jmlediting.profile.jmlref.spec_statement;

