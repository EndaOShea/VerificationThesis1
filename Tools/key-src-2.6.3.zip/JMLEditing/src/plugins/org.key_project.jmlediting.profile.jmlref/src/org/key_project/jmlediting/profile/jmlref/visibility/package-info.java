/**
 * This package contains classes to specify the different visibility keywords.
 */
package org.key_project.jmlediting.profile.jmlref.visibility;

