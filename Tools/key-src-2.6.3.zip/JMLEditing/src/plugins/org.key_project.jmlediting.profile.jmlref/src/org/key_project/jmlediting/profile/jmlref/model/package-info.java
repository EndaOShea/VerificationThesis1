/**
 * This package contains keywords to support model and ghost variables.
 */
package org.key_project.jmlediting.profile.jmlref.model;

