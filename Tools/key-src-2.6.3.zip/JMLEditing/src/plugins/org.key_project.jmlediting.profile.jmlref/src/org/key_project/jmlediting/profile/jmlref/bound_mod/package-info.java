/**
 * Contains classes to implement the bound variable modifiers.
 */
package org.key_project.jmlediting.profile.jmlref.bound_mod;

