/**
 * This package contains the implementation for the different quantifiers in JML expressions.
 */
package org.key_project.jmlediting.profile.jmlref.quantifier;

