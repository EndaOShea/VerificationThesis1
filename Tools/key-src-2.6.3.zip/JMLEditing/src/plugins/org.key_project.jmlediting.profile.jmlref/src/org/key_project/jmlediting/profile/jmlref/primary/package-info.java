/**
 * Support for JML primaries.
 */
package org.key_project.jmlediting.profile.jmlref.primary;

