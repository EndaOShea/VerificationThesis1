/**
 *
 */
/**
 * @author David Giessing
 * package providing Classes for validating JML Specifications.
 */
package org.key_project.jmlediting.profile.jmlref.validator;