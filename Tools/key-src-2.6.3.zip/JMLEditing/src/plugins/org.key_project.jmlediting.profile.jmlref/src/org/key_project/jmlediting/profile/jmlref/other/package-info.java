/**
 * Contains classes for other keyword, which does not fit in the existing packages.
 */
package org.key_project.jmlediting.profile.jmlref.other;

