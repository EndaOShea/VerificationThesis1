/**
 * Includes classes to parse loop invariants.
 */
package org.key_project.jmlediting.profile.jmlref.loop;

