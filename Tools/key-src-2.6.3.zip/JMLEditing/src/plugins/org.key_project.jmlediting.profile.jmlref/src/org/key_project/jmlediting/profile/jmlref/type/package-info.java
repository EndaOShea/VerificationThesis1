/**
 * This package contains classes which defines custom types available in JML expressions.
 */
package org.key_project.jmlediting.profile.jmlref.type;

