/**
 * The package contains classes for specifying the storage location keywords and to
 * parse storage location.
 */
package org.key_project.jmlediting.profile.jmlref.spec_keyword.storeref;

