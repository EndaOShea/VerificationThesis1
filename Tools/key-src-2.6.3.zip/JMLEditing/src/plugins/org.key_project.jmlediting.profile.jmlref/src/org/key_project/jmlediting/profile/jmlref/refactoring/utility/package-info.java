/**
 * This package provides classes used by the refactoring participants to compute the needed
 * changes.
 */
package org.key_project.jmlediting.profile.jmlref.refactoring.utility;

