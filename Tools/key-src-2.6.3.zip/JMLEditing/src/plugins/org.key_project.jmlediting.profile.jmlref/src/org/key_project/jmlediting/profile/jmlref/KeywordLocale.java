package org.key_project.jmlediting.profile.jmlref;

/**
 * Specifies the supported keywords.
 *
 * @author Moritz Lichter
 *
 */
public enum KeywordLocale {
   AMERICAN, BRITISH, BOTH
}