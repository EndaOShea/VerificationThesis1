/**
 * Defines the JML reference profile and the localized versions for american and british english.
 */
package org.key_project.jmlediting.profile.jmlref;

