/**
 * This package contains classes to parse the content of requires keywords.
 */
package org.key_project.jmlediting.profile.jmlref.spec_keyword.requires;

