/**
 * Contains classes, which defines the different behavior keywords.
 */
package org.key_project.jmlediting.profile.jmlref.behavior;

