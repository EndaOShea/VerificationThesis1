/**
 * This package provides the Outline extension classes to extend the outline.
 */
package org.key_project.javaeditor.outline;

